
package modelo;

import conexion.Conector;

/**
 *
 * @author Pablo_Fuentes
 */
public class PaisDAO implements ConsultasPais {
    

/****01. interaccion de codigo java y codigo sql**/
/*se implementa**/


@Override
public boolean insertar(PaisVO p){

Conector c = new Conector();


    try {
     
     c.conectar();

     String query ="INSERT INTO pais (nombre_pais, "
+ "capital_pais, poblacion_pais, fecha_ingreso_pais) "
+ "VALUES ('" + p.getNombrePais()+"', " 
+ "'"+p.getCapitalPais()+"', "
+p.getPoblacionPais()+ ", "
+"'"+p.getFechaIngPais()+"')"; /*LENGUAJE QUE NOS PERMITIRA HACER UNA INSERCION DE NUESTRA TABLA DE NUESTRA BASE DE DATOS*/    

/* SE USA EL GET PORQUE: COMO SON VARIABLES PRIVADAS HAY QUE IR A JALAR LA INFORMACION*/

c.consultasMultiples(query);
return true;
    } catch (Exception e) {
    
            System.err.println("Error [MInsert]: "+e.getMessage());
    c.desconectar();
    }
c.desconectar();
return false;
}


}
