
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.frmInsertar;
import vista.frmMenu;

/**
 *
 * @author Pablo_Fuentes
 */
public class ControladorMenu implements ActionListener {

    frmMenu vMe = new frmMenu();
    frmInsertar vIn = new frmInsertar();
    
    
    public ControladorMenu (frmMenu vMe, frmInsertar vIn){
    
    this.vMe = vMe;
    this.vIn = vIn;
   
    
    vMe.btnInsertar.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
      
       if(e.getSource()==this.vMe.btnInsertar){
       this.vIn.setVisible(true);
       this.vIn.setLocationRelativeTo(vMe);
       this.vIn.setResizable(false);
       
       }
        
        
        
    }
    
    
    
    
}
