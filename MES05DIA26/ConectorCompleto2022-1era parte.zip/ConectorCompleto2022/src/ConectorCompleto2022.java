
import controlador.ControladorInsertar;
import controlador.ControladorMenu;
import modelo.PaisDAO;
import modelo.PaisVO;
import vista.frmInsertar;
import vista.frmMenu;


/**
 *
 * @author Pablo_Fuentes
 */
public class ConectorCompleto2022 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        frmMenu fm = new frmMenu();
        frmInsertar fi = new frmInsertar();
        
    PaisVO pvo = new PaisVO();
    PaisDAO pdao = new PaisDAO();

        ControladorMenu cm = new ControladorMenu(fm, fi);
        ControladorInsertar ci = new ControladorInsertar(fi, pvo, pdao);
        
        fm.setVisible(true);
        fm.setLocationRelativeTo(null);
        
        
        
    }
    
}
