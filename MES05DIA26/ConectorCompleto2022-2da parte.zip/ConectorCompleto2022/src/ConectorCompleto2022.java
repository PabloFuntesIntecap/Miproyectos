
import controlador.ControladorInsertar;
import controlador.ControladorMenu;
import controlador.ControladorMostrar;
import modelo.PaisDAO;
import modelo.PaisVO;
import vista.frmInsertar;
import vista.frmMenu;
import vista.frmMostrar;


/**
 *
 * @author Pablo_Fuentes
 */
public class ConectorCompleto2022 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        frmMenu fm = new frmMenu();
        frmInsertar fi = new frmInsertar();
        frmMostrar fms = new frmMostrar();
    PaisVO pvo = new PaisVO();
    PaisDAO pdao = new PaisDAO();

        ControladorMenu cm = new ControladorMenu(fm, fi, fms);
        ControladorInsertar ci = new ControladorInsertar(fi, pvo, pdao);
        ControladorMostrar cmo = new ControladorMostrar(fms, pvo, pdao);
        fm.setVisible(true);
        fm.setLocationRelativeTo(null);
        
        
        
    }
    
}
