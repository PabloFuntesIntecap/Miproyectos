
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.frmInsertar;
import vista.frmMenu;
import vista.frmMostrar;

/**
 *
 * @author Pablo_Fuentes
 */
public class ControladorMenu implements ActionListener {

    frmMenu vMe = new frmMenu();
    frmInsertar vIn = new frmInsertar();
    frmMostrar vMo = new frmMostrar();
    
    public ControladorMenu (frmMenu vMe, frmInsertar vIn, frmMostrar vMo){
    
    this.vMe = vMe;
    this.vIn = vIn;
    this.vMo = vMo;
    
    vMe.btnInsertar.addActionListener(this);
    vMe.btnMostrar.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
      
       if(e.getSource()==this.vMe.btnInsertar){
       this.vIn.setVisible(true);
       this.vIn.setLocationRelativeTo(vMe);
       this.vIn.setResizable(false);
       
       }
        
        if(e.getSource()==this.vMe.btnMostrar){
       this.vMo.setVisible(true);
       this.vMo.setLocationRelativeTo(vMe);
       this.vMo.setResizable(false);
       
       }     
        
    }
    
    
    
    
}
